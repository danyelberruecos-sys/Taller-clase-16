package packageClase16;

public class Entrada {

	private String codigoBarra;
	
	public Entrada(String codigoBarra) {
		this.codigoBarra = codigoBarra;
	}
	public String getCodigoBarra() {
	    return codigoBarra;
	}
	@Override
	public boolean equals(Object codigoBarra) {

	    if (this == codigoBarra) {
	        return true;
	    }

	    if (!(codigoBarra instanceof Entrada)) {
	        return false;
	    }

	    Entrada otra = (Entrada) codigoBarra;

	    return codigoBarra.equals(otra.codigoBarra);
	}
	@Override
	public int hashCode() {
	    return java.util.Objects.hash(codigoBarra);
	}
	
}

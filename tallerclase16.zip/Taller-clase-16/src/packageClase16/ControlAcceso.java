package packageClase16;
import java.util.HashSet;
import java.util.Set;

public class ControlAcceso {

private Set<Entrada> entradasUsadas;

public ControlAcceso() {
	entradasUsadas = new HashSet<>();
}

public boolean registrarIngreso(Entrada entrada) {
	if(entradasUsadas.contains(entrada)) {
		System.out.println("entrada duplicada.");
		return false;
	}
	entradasUsadas.add(entrada);
	return true;
}

public int contarIngresosValidos() {
	return entradasUsadas.size();
}

}

package packageClase16;

public class PruebaEjercicio02 {

	public static void main(String[] args) {
		ControlAcceso control = new ControlAcceso();
		Entrada entrada1 = new Entrada("AB12");
		boolean resultado1 = control.registrarIngreso(entrada1);
		
		Entrada entrada2 = new Entrada("AB12");
		boolean resultado2 = control.registrarIngreso(entrada2);
		int calidad = control.contarIngresosValidos();
		
		
		System.out.println("----------");	
		System.out.println("entrada 1: " + entrada1);
		
	


	}

}
